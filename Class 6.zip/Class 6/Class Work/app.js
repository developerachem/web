


// This Is loop Pratics

const flower = [ 'golap' , 'kodom' , 'akashi' , 'surjomukhi' , 'beli' , 'hasnahena' , 'alur full' , 'apeler full' , 'gajorer full' , 'amer full' ]

for ( i = 0 ; i < flower.length ; i++ ) {
    console.log( flower[i] );
}


console.log('-------------------------------------------------------------------');

// Foreach Loop Option

flower.forEach( function(data){
    console.log(data);
} )


console.log('-------------------------------------------------------------------');

// Map Loop Option

flower.map( function(fata){
    console.log(fata);
} )




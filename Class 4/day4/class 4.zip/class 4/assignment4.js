

// Create an age calculator function

let ami = (name, age) =>{
    return ` My name is ${name} and i am ${2021 - age} years old`
}

console.log(ami('Nur Amin', 1992));
console.log(ami('Rumman', 1980));
console.log(ami('Siam', 2003));
console.log(ami('Russel', 2001));
console.log(ami('Noyon', 1991));
console.log(ami('Sharil', 1985));
console.log(ami('Abu Raihan', 1989));
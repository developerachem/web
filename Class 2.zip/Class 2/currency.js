



var currency = prompt('Country');
var taka = prompt('Amount');







if( currency == 'USD' ) {
    console.log(` ${ taka } ${currency} = ${ taka * 84 } Taka`);
}else if( currency == 'rupi' ) {
    console.log(` ${ taka } ${currency} = ${ taka * 1.6 } Taka `);
}else if( currency == 'mudra' ) {
    console.log(` ${ taka } ${currency} = ${ taka * 92 } Taka `);
}

























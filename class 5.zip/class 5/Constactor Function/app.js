
let achem = new Achem();



// Entry Calculetor OutPut

// let name = prompt( ` Type Your Name` )
// let age = Number( prompt( ` Type Your Age ` ) )

// console.log( achem.party( name, age ) );







// Age Calculetor OutPut

// let name2 = prompt(` Type Your Name `)
// let year = Number( prompt( ` Type Your Birth Year` ) )

// console.log( achem.age( name2, year ) );







// Currency Calculetor OutPut

// let type1 = prompt(` Type Your Cuntry Code [ USD = (USD) , CAD = (CAD) , Pound = (POUND) , Euro = (EURO) ] `)

// let amount = Number( prompt( ` Type Your Amount ` ) )

// console.log( achem.currency( type1, amount ) );






// Area Calculetor OutPut 

let type = prompt(` What Type ?  [ triangle = (rt) , square = (s) , triangle = (t) ]  `) ;

let height = Number( prompt (` Height ? `) );

let lenth = Number( prompt( ` Lenth ? ` ) )


console.log( achem.area( type, height, lenth ) );




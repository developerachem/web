
let achem = new Achem;


//---------------------------------------------------------------------------------------------------------------------------
// Age Calculetor OutPut



// let name = prompt( `Type Your Name` );
// let age = Number( prompt( ` Type Your Age ` ) )

// console.log( achem.age( name, age ) );




//---------------------------------------------------------------------------------------------------------------------------
// Area Calculetor OutPut



let type = prompt(` Input Type [ triangle = (t) , square = (s) , rectangle = (rt) ] `) ;
let height = Number( prompt( ` Type Height ` ) );
let lenth = Number( prompt(` Type Length `) )


console.log( achem.area( type, height, lenth ) );





//--------------------------------------------------------------------------------------------------------------------------
// This Is AgeCal Output



// let name = prompt(`Type Your Name`)
// let year = Number(prompt( ` Type Your Birth Year ` ))

// console.log( achem.ageCal( name, year ) );



//---------------------------------------------------------------------------------------------------------------------------
// This Is Currency Converter Output


// let type = prompt(` Type Uour Country Code { Doller = (USD) , Pound = (POUND) , Youro = (EURO ) , Cad = (CAD) } `) ;
// let amount = Number(prompt(`Type Amount`))

// console.log(achem.currency( type, amount ));

//----------------------------------------------------------------------------------------------------------------------------
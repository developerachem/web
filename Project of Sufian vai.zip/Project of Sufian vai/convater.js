

let country = prompt('Type Your Counmtry')
let taka = prompt('Type Your Taka')





if( country == 'USA' ) {
    console.log(` Your Country ${ country } Your Taka $${taka} = ${ taka * 84 } BDT Taka `);
}else if( country == 'uro'){
    console.log(` Your Country ${ country } Your Taka @${taka} = ${ taka * 25 } BDT Taka `);
}else if( country == 'rupi'){
    console.log(` Your Country ${ country } Your Taka &${taka} = ${ taka * 95 } BDT Taka `);
}else if( country == 'rial'){
    console.log(` Your Country ${ country } Your Taka @${taka} = ${ taka * 21 } BDT Taka `);
}



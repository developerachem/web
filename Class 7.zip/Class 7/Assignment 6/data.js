const student = [

    {

        id           : 01,
        name         : 'Md Abu Raihan',
        age          : 21,
        selary       : 50000,
        location     : 'Sherpur'

    },

    {

        id           : 02,
        name         : 'Md Abu Sufiyan',
        age          : 27,
        selary       : 45000,
        location     : 'Dhaka'

    },

    {

        id           : 03,
        name         : 'Md Achem',
        age          : 24,
        selary       : 46000,
        location     : 'Mirpur'

    },

    {

        id           : 04,
        name         : 'Md Mamun',
        age          : 23,
        selary       : 44000,
        location     : 'Rangpur'

    },

    {

        id           : 05,
        name         : 'Md Abu Sayeed',
        age          : 21,
        selary       : 41000,
        location     : 'Banani'

    },

    {

        id           : 06,
        name         : 'Md Aarul',
        age          : 20,
        selary       : 40000,
        location     : 'Mirpur'

    },

    {

        id           : 07,
        name         : 'Md Abani',
        age          : 21,
        selary       : 41000,
        location     : 'Rangpur'

    },

    
    {

        id           : 08,
        name         : 'Md Abanimohon',
        age          : 21,
        selary       : 41000,
        location     : 'Banani'

    },

    {

        id           : 09,
        name         : 'Md Abanish',
        age          : 21,
        selary       : 19000,
        location     : 'Mirpur'

    },

    {

        id           : 10,
        name         : 'Md Abhijeet',
        age          : 20,
        selary       : 18000,
        location     : 'Dhaka'

    },

    {

        id           : 11,
        name         : 'Md Abhik',
        age          : 20,
        selary       : 18000,
        location     : 'Mirpur'

    },

    {

        id           : 12,
        name         : 'Md Abhik',
        age          : 20,
        selary       : 18000,
        location     : 'Dhaka'

    },

    {

        id           : 13,
        name         : 'Md Adrisar',
        age          : 19,
        selary       : 17000,
        location     : 'Mirpur'

    },

    {

        id           : 14,
        name         : 'Md Ajatasmatru',
        age          : 18,
        selary       : 16000,
        location     : 'Banani'

    },

    {

        id           : 15,
        name         : 'Md Akashadhar',
        age          : 18,
        selary       : 16000,
        location     : 'Dhaka'

    },

    {

        id           : 16,
        name         : 'Md Amitava',
        age          : 17,
        selary       : 15000,
        location     : 'Mirpur'

    },

    {

        id           : 17,
        name         : 'Md Balmiki',
        age          : 17,
        selary       : 16000,
        location     : 'Banani'

    },

    {

        id           : 18,
        name         : 'Md Balmiki',
        age          : 18,
        selary       : 16000,
        location     : 'Mirpur'

    },

    {

        id           : 19,
        name         : 'Md Banaful',
        age          : 19,
        selary       : 19000,
        location     : 'Banani'

    },

    {

        id           : 20,
        name         : 'Md Basav',
        age          : 15,
        selary       : 14000,
        location     : 'Dhaka'

    },

    {

        id           : 21,
        name         : 'Md Benoy',
        age          : 16,
        selary       : 15000,
        location     : 'Banani'

    },

    {

        id           : 22,
        name         : 'Md Bhageerath',
        age          : 17,
        selary       : 17000,
        location     : 'Mirpur'

    },

    {

        id           : 23,
        name         : 'Md Bhaskor',
        age          : 18,
        selary       : 13000,
        location     : 'Banani'

    },

    {

        id           : 24,
        name         : 'Md Buburam',
        age          : 17,
        selary       : 18000,
        location     : 'Sherpur'

    },

    {

        id           : 25,
        name         : 'Md Buburam',
        age          : 18,
        selary       : 14000,
        location     : 'Banani'

    }, 

    {

        id           : 26,
        name         : 'Md Chaitali',
        age          : 14,
        selary       : 17000,
        location     : 'Mirpur'

    }, 

    {

        id           : 27,
        name         : 'Md Chandrachur',
        age          : 19,
        selary       : 19000,
        location     : 'Bogura'

    },

    {

        id           : 28,
        name         : 'Md Daiwik',
        age          : 17,
        selary       : 13000,
        location     : 'Banani'

    },

    {

        id           : 29,
        name         : 'Md Devesh',
        age          : 16,
        selary       : 13000,
        location     : 'Sherpur'

    },

    {

        id           : 30,
        name         : 'Md Dipankar',
        age          : 19,
        selary       : 17000,
        location     : 'Mirpur'

    },

    
    {

        id           : 31,
        name         : 'Md Fanikeshar',
        age          : 20,
        selary       : 12000,
        location     : 'Rangpur'

    },


    {

        id           : 32,
        name         : 'Md Gangaraaju',
        age          : 21,
        selary       : 14000,
        location     : 'Banani'

    },

    
    {

        id           : 33,
        name         : 'Md Hironmoe',
        age          : 22,
        selary       : 13000,
        location     : 'Mirpur'

    },

    {

        id           : 34,
        name         : 'Md Hridyanshu',
        age          : 23,
        selary       : 15000,
        location     : 'Banani'

    },

    
    {

        id           : 35,
        name         : 'Md Jayaketan',
        age          : 22,
        selary       : 17000,
        location     : 'Mirpur'

    },

    {

        id           : 36,
        name         : 'Md Jayanand',
        age          : 23,
        selary       : 15000,
        location     : 'Dhaka'

    },

    {

        id           : 37,
        name         : 'Md Jaydeb',
        age          : 23,
        selary       : 16000,
        location     : 'Mirpur'

    },

    {

        id           : 38,
        name         : 'Md Jhareshwar',
        age          : 26,
        selary       : 16000,
        location     : 'Dhaka'

    },

    {

        id           : 39,
        name         : 'Md Joeonto',
        age          : 27,
        selary       : 17000,
        location     : 'Rangpur'

    },

    {

        id           : 40,
        name         : 'Md Kaustubh',
        age          : 21,
        selary       : 17000,
        location     : 'Mirpur'

    },

    {

        id           : 41,
        name         : 'Md Lekhon',
        age          : 22,
        selary       : 15000,
        location     : 'Banani'

    },

    {

        id           : 42,
        name         : 'Md Modanatha',
        age          : 23,
        selary       : 17000,
        location     : 'Mirpur'

    },
    
    
    {

        id           : 43,
        name         : 'Md Nabhas',
        age          : 22,
        selary       : 19000,
        location     : 'Bogura'

    },

    {

        id           : 44,
        name         : 'Md Nabin',
        age          : 25,
        selary       : 20000,
        location     : 'Mirpur'

    },

    {

        id           : 45,
        name         : 'Md Nabinchandra',
        age          : 26,
        selary       : 23000,
        location     : 'Banani'

    },

    {

        id           : 46,
        name         : 'Md Ohitlal',
        age          : 24,
        selary       : 23000,
        location     : 'Mirpur'

    },
    

    {

        id           : 47,
        name         : 'Md Ongkar',
        age          : 26,
        selary       : 22000,
        location     : 'Banani'

    },

    {

        id           : 48,
        name         : 'Md Palash',
        age          : 25,
        selary       : 23000,
        location     : 'Mirpur'

    },

    {

        id           : 48,
        name         : 'Md Palash',
        age          : 26,
        selary       : 23000,
        location     : 'Dhaka'

    },

    {

        id           : 49,
        name         : 'Md Partho',
        age          : 28,
        selary       : 23000,
        location     : 'Mirpur'

    },

    {

        id           : 50,
        name         : 'Md Pingakshi',
        age          : 22,
        selary       : 20000,
        location     : 'Banani'

    },
];